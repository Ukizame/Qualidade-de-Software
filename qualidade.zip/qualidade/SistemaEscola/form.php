<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/form.css">
    <title>Sistema Escolar</title>
</head>

<body>
    <h1>Sistema Escolar</h1>
    <div class="container">
        <form method="post">
            <label class="texto">Codigo de Acesso: </label>
            <input class="form-control" type="user" name="cod_acesso" pattern="[0-9]*">
            <label class="texto">Senha: </label>
            <input class="form-control" type="password" name="senha">
            <input type="submit" name="logar" value='Login'>
            <input type="submit" name="cadastrar" value='Cadastrar'>
        </form>
    </div>
</body>

</html>
<?php

require_once '../vendor/autoload.php';
Sentry\init(['dsn' => 'https://cc7260d8c3a2455c9c8ee0557dfd04f9@o4504261536251904.ingest.sentry.io/4504261537628160' ]);

session_start();
if (isset($_SESSION['login']) and (isset($_SESSION['senha']))) {
    header('Location:index.php');
}

if (isset($_POST['logar'])) {
    $cod_acesso = $_POST['cod_acesso'];
    $senha = $_POST['senha'];
    include 'autenticacao_login.php';
}

if (isset($_POST['cadastrar'])) {
    header('Location:cadastro.php');
}

if (isset($_COOKIE['status_login'])) {
    if ($_COOKIE['status_login'] == 'true') {
        echo 'Codigo de acesso ou senha invalidos.';
        setcookie('status_login', 'false');
    }
}
